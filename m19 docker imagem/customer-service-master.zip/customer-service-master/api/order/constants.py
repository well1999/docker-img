ADDRESS_EXCHANGE = 'address-exchange'
ADDRESS_PRODUCER_ROUTING_KEY = 'address'
ADDRESS_PRODUCER_QUEUE = 'order-customer-queue'

ADDRESS_CONSUMER_ROUTING_KEY = 'geo-location'
ADDRESS_CONSUMER_QUEUE = 'order-address-queue'
